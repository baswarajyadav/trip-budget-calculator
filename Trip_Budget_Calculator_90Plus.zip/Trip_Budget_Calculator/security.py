"""Security helpers: validation, safe paths and CSV formula protection."""
from pathlib import Path
import os
import re

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
REPORT_DIR = ROOT / "reports"
BACKUP_DIR = ROOT / "backups"

def ensure_directories():
    for folder in (DATA_DIR, REPORT_DIR, BACKUP_DIR):
        folder.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(folder, 0o700)
        except OSError:
            pass

def safe_filename(name: str, suffix: str) -> Path:
    """Only allow a simple filename; never accept directory traversal."""
    if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,40}", name):
        raise ValueError("Invalid file name. Use letters, numbers, _ or - only.")
    return REPORT_DIR / f"{name}.{suffix}"

def csv_safe(value):
    """Neutralize spreadsheet formula injection in exported text fields."""
    text = str(value)
    if text.startswith(("=", "+", "-", "@", "\t", "\r")):
        return "'" + text
    return text
