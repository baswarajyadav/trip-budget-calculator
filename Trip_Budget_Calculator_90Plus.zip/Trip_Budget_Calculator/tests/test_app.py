import sys
import unittest
from pathlib import Path
from decimal import Decimal
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from models import Trip
from calculator import analytics, search_trips
from storage import TripStorage

def sample():
    return Trip.from_dict({
        "trip_id": "T001", "destination": "Hyderabad", "start_date": "2026-12-10",
        "days": 2, "transport": "1000", "stay": "2000", "food": "800",
        "activities": "500", "budget": "5000", "notes": "College trip"
    })

class TripTests(unittest.TestCase):
    def test_total(self):
        self.assertEqual(sample().total, Decimal("4300.00"))

    def test_budget_status(self):
        self.assertEqual(sample().status, "WITHIN BUDGET")

    def test_reject_negative_amount(self):
        raw = sample().to_dict()
        raw["food"] = "-10"
        with self.assertRaises(ValueError):
            Trip.from_dict(raw)

    def test_reject_invalid_date(self):
        raw = sample().to_dict()
        raw["start_date"] = "not-a-date"
        with self.assertRaises(ValueError):
            Trip.from_dict(raw)

    def test_analytics(self):
        result = analytics([sample()])
        self.assertEqual(result["count"], 1)
        self.assertEqual(result["spent"], Decimal("4300.00"))

    def test_search(self):
        self.assertEqual(len(search_trips([sample()], "hyderabad")), 1)
        self.assertEqual(len(search_trips([sample()], "", "food")), 1)

    def test_json_persistence(self):
        import tempfile
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "trips.json"
            store = TripStorage(path)
            store.save([sample()])
            self.assertEqual(store.load()[0].trip_id, "T001")

if __name__ == "__main__":
    unittest.main()
