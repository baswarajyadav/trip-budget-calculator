"""CampusSolve Project #51: Trip Budget Calculator."""
from datetime import date
from decimal import Decimal
from uuid import uuid4
from pathlib import Path
from models import Trip, CATEGORIES
from storage import TripStorage, StorageError
from calculator import analytics, search_trips
from reports import export_csv, export_markdown, import_csv

def ask_text(prompt, limit=80):
    while True:
        value = input(prompt).strip()
        try:
            if not value or len(value) > limit or any(ord(c) < 32 for c in value):
                raise ValueError
            return value
        except ValueError:
            print(f"Enter 1-{limit} valid characters.")

def ask_int(prompt, low, high):
    while True:
        try:
            value = int(input(prompt).strip())
            if low <= value <= high:
                return value
        except ValueError:
            pass
        print(f"Enter a whole number from {low} to {high}.")

def ask_money(prompt):
    while True:
        raw = input(prompt).strip()
        try:
            value = Decimal(raw)
            if value.is_finite() and Decimal("0") <= value <= Decimal("100000000"):
                return str(value.quantize(Decimal("0.01")))
        except Exception:
            pass
        print("Enter a valid amount from 0 to 100,000,000.")

def ask_date():
    while True:
        raw = input("Start date (YYYY-MM-DD): ").strip()
        try:
            return date.fromisoformat(raw).isoformat()
        except ValueError:
            print("Invalid date. Example: 2026-12-15")

def add_trip(storage, trips):
    print("\n--- Add New Trip ---")
    destination = ask_text("Destination: ")
    start = ask_date()
    days = ask_int("Number of days (1-365): ", 1, 365)
    costs = {c: ask_money(f"{c.title()} cost (₹): ") for c in CATEGORIES}
    budget = ask_money("Total planned budget (₹): ")
    notes = ask_text("Notes (or enter 'No notes'): ", 250)
    trip = Trip.from_dict({
        "trip_id": uuid4().hex[:10], "destination": destination,
        "start_date": start, "days": days, **costs, "budget": budget, "notes": notes
    })
    trips.append(trip)
    storage.backup()
    storage.save(trips)
    print(f"Saved! Trip ID: {trip.trip_id} | Estimated total: ₹{trip.total:.2f}")
    if trip.remaining < 0:
        print(f"WARNING: Over budget by ₹{abs(trip.remaining):.2f}")

def show_trips(trips):
    if not trips:
        print("No trip records found.")
        return
    print("\n" + "-" * 92)
    print(f"{'ID':10} {'DESTINATION':20} {'DATE':12} {'TOTAL (₹)':14} {'BUDGET (₹)':14} STATUS")
    print("-" * 92)
    for t in trips:
        print(f"{t.trip_id:10} {t.destination[:20]:20} {t.start_date:12} "
              f"{t.total:14.2f} {Decimal(t.budget):14.2f} {t.status}")
    print("-" * 92)

def show_analytics(trips):
    a = analytics(trips)
    print("\n--- Executive Summary ---")
    print(f"Trips recorded       : {a['count']}")
    print(f"Planned budget       : ₹{a['planned']:.2f}")
    print(f"Total expenses       : ₹{a['spent']:.2f}")
    print(f"Average per trip     : ₹{a['average']:.2f}")
    print(f"Over-budget trips    : {a['over_budget']}")
    for name, amount in a["categories"].items():
        print(f"{name.title():20}: ₹{amount:.2f}")

def main():
    storage = TripStorage()
    try:
        trips = storage.load()
    except StorageError as exc:
        print(f"\nSECURITY / DATA WARNING: {exc}")
        print("The existing data was not overwritten. Restore a trusted backup before continuing.")
        return

    print("=" * 54)
    print("       CAMPUSSOLVE | TRIP BUDGET CALCULATOR")
    print("          Plan smart. Travel confidently.")
    print("=" * 54)
    while True:
        print("""
1. Add new trip
2. View all trips
3. Search trips
4. Executive analytics
5. Export CSV report
6. Export Markdown report
7. Import CSV dataset
8. Exit
""")
        choice = input("Choose an option (1-8): ").strip()
        try:
            if choice == "1":
                add_trip(storage, trips)
            elif choice == "2":
                show_trips(trips)
            elif choice == "3":
                keyword = input("Destination/notes keyword (blank for all): ").strip()
                category = input("Category (all/transport/stay/food/activities): ").strip().lower() or "all"
                show_trips(search_trips(trips, keyword, category))
            elif choice == "4":
                show_analytics(trips)
            elif choice == "5":
                path = export_csv(trips)
                print(f"CSV report saved: {path}")
            elif choice == "6":
                path = export_markdown(trips)
                print(f"Markdown report saved: {path}")
            elif choice == "7":
                source = input("CSV file path: ").strip()
                imported, errors = import_csv(source)
                existing = {t.trip_id for t in trips}
                added = [t for t in imported if t.trip_id not in existing]
                trips.extend(added)
                storage.backup()
                storage.save(trips)
                print(f"Imported {len(added)} records.")
                for error in errors:
                    print(error)
            elif choice == "8":
                print("Thank you for using Trip Budget Calculator!")
                break
            else:
                print("Invalid choice. Select 1-8.")
        except (ValueError, OSError, StorageError) as exc:
            print(f"Operation could not be completed: {exc}")

if __name__ == "__main__":
    main()
