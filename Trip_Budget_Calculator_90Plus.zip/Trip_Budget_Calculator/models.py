"""Validated domain models for CampusSolve Trip Budget Calculator."""
from dataclasses import dataclass, asdict
from datetime import date
from decimal import Decimal, InvalidOperation
from typing import Any
import re

CATEGORIES = ("transport", "stay", "food", "activities")
MAX_AMOUNT = Decimal("100000000")
MAX_TEXT = 80

def clean_text(value: Any, field: str, limit: int = MAX_TEXT) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{field} must be text.")
    value = " ".join(value.strip().split())
    if not value or len(value) > limit:
        raise ValueError(f"{field} must contain 1-{limit} characters.")
    if any(ord(ch) < 32 for ch in value):
        raise ValueError(f"{field} contains invalid control characters.")
    return value

def money(value: Any) -> str:
    try:
        amount = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError):
        raise ValueError("Amount must be a valid number.")
    if not amount.is_finite() or amount < 0 or amount > MAX_AMOUNT:
        raise ValueError("Amount must be between 0 and 100,000,000.")
    return str(amount.quantize(Decimal("0.01")))

@dataclass
class Trip:
    trip_id: str
    destination: str
    start_date: str
    days: int
    transport: str
    stay: str
    food: str
    activities: str
    budget: str
    notes: str = ""

    @property
    def total(self) -> Decimal:
        return sum((Decimal(getattr(self, c)) for c in CATEGORIES), Decimal("0.00"))

    @property
    def remaining(self) -> Decimal:
        return Decimal(self.budget) - self.total

    @property
    def status(self) -> str:
        return "OVER BUDGET" if self.remaining < 0 else "WITHIN BUDGET"

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, raw):
        if not isinstance(raw, dict):
            raise ValueError("Each trip record must be an object.")
        required = {"trip_id", "destination", "start_date", "days",
                    "transport", "stay", "food", "activities", "budget"}
        if not required.issubset(raw):
            raise ValueError("Trip record is missing required fields.")
        trip_id = clean_text(raw["trip_id"], "Trip ID", 40)
        if not re.fullmatch(r"[A-Za-z0-9_-]+", trip_id):
            raise ValueError("Trip ID contains unsupported characters.")
        destination = clean_text(raw["destination"], "Destination")
        try:
            parsed = date.fromisoformat(str(raw["start_date"]))
        except (ValueError, TypeError):
            raise ValueError("Date must use YYYY-MM-DD format.")
        try:
            days = int(raw["days"])
        except (ValueError, TypeError):
            raise ValueError("Days must be a whole number.")
        if not 1 <= days <= 365:
            raise ValueError("Days must be between 1 and 365.")
        amounts = {c: money(raw[c]) for c in CATEGORIES}
        budget = money(raw["budget"])
        notes = clean_text(raw.get("notes", "No notes"), "Notes", 250)
        return cls(trip_id, destination, parsed.isoformat(), days,
                   amounts["transport"], amounts["stay"], amounts["food"],
                   amounts["activities"], budget, notes)
