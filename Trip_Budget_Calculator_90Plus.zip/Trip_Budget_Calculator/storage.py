"""Local JSON persistence with validation, atomic writes and backups."""
import json
import os
import shutil
import tempfile
from pathlib import Path
from models import Trip
from security import DATA_DIR, BACKUP_DIR, ensure_directories

DB_FILE = DATA_DIR / "trips.json"

class StorageError(Exception):
    pass

class TripStorage:
    def __init__(self, path=DB_FILE):
        self.path = Path(path)
        ensure_directories()

    def load(self):
        if not self.path.exists():
            return []
        try:
            with self.path.open("r", encoding="utf-8") as handle:
                raw = json.load(handle)
            if not isinstance(raw, list):
                raise StorageError("Database root must be a JSON list.")
            trips = [Trip.from_dict(item) for item in raw]
            ids = [t.trip_id for t in trips]
            if len(ids) != len(set(ids)):
                raise StorageError("Duplicate trip IDs detected.")
            return trips
        except (json.JSONDecodeError, UnicodeDecodeError, ValueError, TypeError) as exc:
            raise StorageError(f"Stored data is invalid: {exc}") from exc

    def save(self, trips):
        ensure_directories()
        payload = [trip.to_dict() for trip in trips]
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp_name = None
        try:
            with tempfile.NamedTemporaryFile("w", encoding="utf-8",
                    dir=self.path.parent, delete=False, newline="") as handle:
                temp_name = handle.name
                json.dump(payload, handle, indent=2, ensure_ascii=False)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp_name, self.path)
            try:
                os.chmod(self.path, 0o600)
            except OSError:
                pass
        except OSError as exc:
            if temp_name and os.path.exists(temp_name):
                os.unlink(temp_name)
            raise StorageError(f"Could not save data: {exc}") from exc

    def backup(self):
        if self.path.exists():
            ensure_directories()
            target = BACKUP_DIR / "trips_backup.json"
            shutil.copy2(self.path, target)
            try:
                os.chmod(target, 0o600)
            except OSError:
                pass
            return target
        return None
