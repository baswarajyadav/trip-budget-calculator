# CampusSolve Project #51 — Trip Budget Calculator

A modular, beginner-friendly Python 3.10+ application for estimating and tracking trip costs.

## Features
- Transport, stay, food and activity cost calculation
- Defensive validation for dates, text, day counts and monetary values
- JSON persistence with atomic replacement and local backup
- Search by destination/notes and expense category
- Executive analytics and over-budget alerts
- CSV import/export and Markdown report generation
- Spreadsheet formula-injection mitigation on CSV exports
- Unit tests for calculation, validation, search, analytics and persistence

## Architecture
1. Presentation: `app.py` — menu and guided user interaction
2. Domain model: `models.py` — validated `Trip` data model
3. Business logic: `calculator.py` — calculations, search and analytics
4. Security: `security.py` — safe report filenames, input/output protections
5. Persistence: `storage.py` — validated JSON, atomic writes and backups
6. Reporting: `reports.py` — CSV/Markdown export and defensive CSV import

## Requirements
- Python 3.10 or later
- Standard library only; no third-party packages required

## Run
Open a terminal in this folder:

```bash
python app.py
```

## Run tests
```bash
python -m unittest discover -s tests -v
```

## Data files
- `data/trips.json` stores trip records.
- `backups/trips_backup.json` stores the previous database before updates.
- Generated reports are written to `reports/`.

## Security notes
- All imported and loaded records are validated before use.
- Amounts are bounded and must be finite and non-negative.
- Trip IDs are restricted to a safe character set.
- Report filenames cannot contain path separators or traversal sequences.
- CSV exports neutralize common spreadsheet formula prefixes in text cells.
- JSON writes use a temporary file and atomic replacement to reduce corruption risk.
- Local file permissions are restricted where the operating system supports it.

This is a local single-user educational application, not a production multi-user financial service. For production deployment, add authenticated user accounts, encryption at rest, OS-backed secrets, access auditing and tested off-device backups.
