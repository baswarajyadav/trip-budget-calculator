"""Report and CSV import/export helpers."""
import csv
from datetime import datetime
from decimal import Decimal
from models import Trip
from security import safe_filename, csv_safe
from calculator import analytics

def export_csv(trips, filename="trip_report"):
    path = safe_filename(filename, "csv")
    fields = ["trip_id", "destination", "start_date", "days", "transport",
              "stay", "food", "activities", "budget", "total", "remaining", "status", "notes"]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for t in trips:
            row = t.to_dict()
            row.update(total=str(t.total), remaining=str(t.remaining), status=t.status)
            writer.writerow({k: csv_safe(v) for k, v in row.items()})
    return path

def export_markdown(trips, filename="trip_summary"):
    path = safe_filename(filename, "md")
    stats = analytics(trips)
    lines = ["# Trip Budget Calculator Report", "",
             f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}", "",
             "## Executive Summary", "",
             f"- Trips: {stats['count']}",
             f"- Planned budget: ₹{stats['planned']:.2f}",
             f"- Total expenses: ₹{stats['spent']:.2f}",
             f"- Average expense per trip: ₹{stats['average']:.2f}",
             f"- Over-budget trips: {stats['over_budget']}", "",
             "## Trip Details", "",
             "| ID | Destination | Date | Total | Budget | Status |",
             "|---|---|---|---:|---:|---|"]
    for t in trips:
        dest = t.destination.replace("|", "-")
        lines.append(f"| {t.trip_id} | {dest} | {t.start_date} | ₹{t.total:.2f} | ₹{Decimal(t.budget):.2f} | {t.status} |")
    lines += ["", "## Category Totals", ""]
    for key, value in stats["categories"].items():
        lines.append(f"- {key.title()}: ₹{value:.2f}")
    path.write_text("\n".join(lines), encoding="utf-8")
    return path

def import_csv(path):
    """Import rows defensively; returns (valid_trips, row_errors)."""
    trips, errors = [], []
    with open(path, newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        required = {"trip_id", "destination", "start_date", "days", "transport",
                    "stay", "food", "activities", "budget"}
        if not reader.fieldnames or not required.issubset(set(reader.fieldnames)):
            raise ValueError("CSV is missing required column headings.")
        for line, row in enumerate(reader, start=2):
            try:
                trips.append(Trip.from_dict(row))
            except (ValueError, TypeError) as exc:
                errors.append(f"Row {line}: {exc}")
    return trips, errors
