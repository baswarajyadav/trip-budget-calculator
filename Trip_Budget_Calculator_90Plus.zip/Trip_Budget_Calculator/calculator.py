"""Business logic and analytics."""
from decimal import Decimal
from collections import defaultdict
from models import CATEGORIES

def calculate_total(trip):
    return trip.total

def analytics(trips):
    count = len(trips)
    if not count:
        return {"count": 0, "planned": Decimal("0"), "spent": Decimal("0"),
                "average": Decimal("0"), "over_budget": 0, "categories": {}}
    planned = sum((Decimal(t.budget) for t in trips), Decimal("0"))
    spent = sum((t.total for t in trips), Decimal("0"))
    categories = {
        category: sum((Decimal(getattr(t, category)) for t in trips), Decimal("0"))
        for category in CATEGORIES
    }
    return {
        "count": count, "planned": planned, "spent": spent,
        "average": spent / count,
        "over_budget": sum(t.remaining < 0 for t in trips),
        "categories": categories
    }

def search_trips(trips, keyword="", category="all"):
    keyword = keyword.casefold().strip()
    if category not in ("all",) + CATEGORIES:
        raise ValueError("Unknown category.")
    results = []
    for trip in trips:
        searchable = f"{trip.destination} {trip.notes}".casefold()
        category_match = category == "all" or Decimal(getattr(trip, category)) > 0
        if (not keyword or keyword in searchable) and category_match:
            results.append(trip)
    return results
